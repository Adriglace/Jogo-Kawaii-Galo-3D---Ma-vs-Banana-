# Jogo Kawaii Galo 3D – Maçã vs Banana

Um jogo fofo e divertido onde frutas disputam o clássico jogo da velha em 3D!

**Feito com carinho por Adriglace – Adriana Soares**

- Estilo: Kawaii
- Personagens: Maçã e Banana
- Plataforma: GitHub Pages e Netlify

**Jogue agora:** https://jogo-kawaii-galo3d.netlify.app/
